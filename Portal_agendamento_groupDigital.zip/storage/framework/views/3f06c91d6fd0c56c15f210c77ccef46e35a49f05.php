<?php $__env->startSection('titulo','Portal Agendamento'); ?>

<?php $__env->startSection('corpo'); ?>
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <?php if(Auth::guest()): ?>
        <?php else: ?>
        <div class = "card-panel">
           <h4>Bem Vindo!!</h4> <smail><?php echo e(Auth::user()->name); ?></smail>
      </div>
        <?php endif; ?>
        <h1 class="header center teal-text text-lighten-2">Portal Agendamento</h1>
        <div class="row center">
          <h5 class="header col s12 light">A agilidade e a possibilidade de agendar a entrada dos vizitantes e acessar informações em tempo real</h5>
        </div>
        <?php if(Auth::guest()): ?>
        <div class="row center">
          <a href="<?php echo e(route('site.login')); ?>" id="download-button" class="btn-large waves-effect waves-light teal lighten-1 pulse">Faça o Login</a>
        </div>
        <?php else: ?>

        <div class="row">
            <div class="col s12 m4">
              <a href="<?php echo e(route('admin.aparatamento.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra apartamento">Cadastro Apartamento</a>
            </div>
            <div class="col s12 m4">
              <a href="<?php echo e(route('admin.condomino.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra novo morador">Cadastro Condomino</a>
            </div>
            <div class="col s12 m4">
              <a href="<?php echo e(route('admin.visitante.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra visitante e agenda entrada">Cadastro Visitante</a>
            </div>
        </div>
        <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>