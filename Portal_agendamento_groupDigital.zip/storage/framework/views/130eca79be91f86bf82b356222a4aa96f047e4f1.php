<?php $__env->startSection('titulo', 'Lista Condomino'); ?>

<?php $__env->startSection('corpo'); ?>
<div class="container">
  <h3 class="center">Lista de Condomino</h3>
    <div class="row">
      <table class="bordered centered">
        <thead>
          <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Conj/Torre</th>
            <th>Apartamento</th>
            <th>imagem</th>
            <th>Ativo</th>
            <th>Ação</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td><?php echo e($registro->id_condomino); ?></td>
            <td><?php echo e($registro->nome); ?></td>
            <td><?php echo e($registro->sobrenome); ?></td>
            <td><?php echo e($registro->conj); ?></td>
            <td><?php echo e($registro->numapart); ?></td>
            <td>
              <img width="60" height="60" src="<?php echo e(asset($registro->imagem)); ?>" alt="$registro->nome">
            </td>
            <td style="<?php echo e(isset($registro->status) && $registro->status == 'sim' ? 'color:#039be5' : 'color:red'); ?>"><?php echo e($registro->status); ?></td>
            <td>
              <a href="<?php echo e(route('admin.condomino.editar',$registro->id_condomino)); ?>" class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Editar">
                <i class="material-icons" style="font-size:2rem">create</i></a>
              <a href="<?php echo e(route('admin.visitante',$registro->id_condomino)); ?>"class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Visitantes">
                <i class="large material-icons" style="font-size:2rem">view_agenda</i></a>
              <a href="<?php echo e(route('admin.condomino.deletar',$registro->id_condomino)); ?>"class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Deletar">
                <i class="large material-icons" style="font-size:2rem">delete_forever</i></a>
            </td>
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>

      </table>
        <!-- Scaled in -->
        <a id="scale-demo" href="<?php echo e(route('admin.condomino.adicionar')); ?>" class="btn-floating btn-large scale-transition tooltipped" data-position="bottom" data-delay="50" data-tooltip="Novo Condomino">
          <i class="material-icons">add</i>
        </a>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>