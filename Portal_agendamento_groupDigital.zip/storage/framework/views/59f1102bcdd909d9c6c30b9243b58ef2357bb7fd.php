<?php $__env->startSection('titulo', 'Adicionar Apartamento'); ?>

<?php $__env->startSection('corpo'); ?>
<div class="container">
  <h3 class="center">Adicionar Apartamento</h3>
  <div class="row">
    <div class="card-panel hoverable center-align">
      <p><h5 class="red-text">Estamos em desenvolvimento</h5></p>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>