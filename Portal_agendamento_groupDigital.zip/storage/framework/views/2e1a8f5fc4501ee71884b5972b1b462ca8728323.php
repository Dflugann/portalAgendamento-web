<?php $__env->startSection('titulo', "Login"); ?>

<?php $__env->startSection('corpo'); ?>

<div class="container">
  <h3 class="center">Login</h3>
  <div class="row">
    <form class="col s12" action="<?php echo e(route('site.login.entrar')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <div class="input-field col s12 m6">
            <i class="material-icons prefix">email</i>
            <input type="text" name="email">
            <label >E-mail</label>
          </div>
          <div class="input-field col s12 m6">
            <i class="material-icons prefix">vpn_key</i>
            <input type="password" name="senha">
            <label>Password</label>
          </div>

          <div class="center">
            <button class="btn green pulse">Entrar</button>
          </div>
    </form>

  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>