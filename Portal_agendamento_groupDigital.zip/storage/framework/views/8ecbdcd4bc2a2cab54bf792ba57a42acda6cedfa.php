<?php $__env->startSection('titulo', 'Adicionar Condomino'); ?>

<?php $__env->startSection('corpo'); ?>
<div class="container">
  <h3 class="center">Adicionar Condomino</h3>
    <div class="row">
      <form class="col s12" action="<?php echo e(route('admin.condomino.salvar')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo $__env->make('admin.condomino._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <button class="btn green">Enviar</button>
      </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>