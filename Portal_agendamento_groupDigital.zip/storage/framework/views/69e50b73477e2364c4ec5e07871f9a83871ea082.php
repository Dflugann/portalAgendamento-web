<?php $__env->startSection('titulo','Index'); ?>

<?php $__env->startSection('corpo'); ?>	
<h3>Teste INDEX VIEWS</h3>

	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<p><?php echo e($dados->nome); ?></p>
		<p><?php echo e($dados->tel); ?></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
@endsenction


<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>