<?php $__env->startSection('titulo','Portal Agendamento'); ?>

<?php $__env->startSection('corpo'); ?>
<div class="container">
  <div class="section ">
    <div class="row">
      <h1>Portal Agendamento</h1><br />
      <h4 class="center light">Cadastro</h4>
      <hr>
    </div>
    <div class="row">
        <div class="col s12 m4">
          <a href="<?php echo e(route('admin.aparatamento.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra apartamento">Cadastro Apartamento</a>
        </div>
        <div class="col s12 m4">
          <a href="<?php echo e(route('admin.condomino.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra novo morador">Cadastro Condomino</a>
        </div>
        <div class="col s12 m4">
          <a href="<?php echo e(route('admin.visitante.adicionar')); ?>" class="btn tooltipped" data-position="bottom" data-delay="50" data-tooltip="Aqui você cadastra visitante e agenda entrada">Cadastro Visitante</a>
        </div>
    </div>

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>