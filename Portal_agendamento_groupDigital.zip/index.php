<?php
$redirect = "public";

header("location:$redirect");

?>
<?php
