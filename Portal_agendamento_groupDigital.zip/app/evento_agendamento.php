<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class evento_agendamento extends Model
{
    //
}
